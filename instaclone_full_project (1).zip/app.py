import os, re, base64, uuid
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from sqlalchemy.orm import Session
from database import Base, engine, SessionLocal
from models import User, Post, Comment, Follow, Story, Collection, CollectionItem, Notification

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
CORS(app)
Base.metadata.create_all(bind=engine)

# ---- helpers ----

def save_data_url(data_url: str) -> str:
    # data_url like "data:image/png;base64,...."
    m = re.match(r"data:(?P<mime>[^;]+);base64,(?P<b64>.+)", data_url)
    if not m:
        raise ValueError("Invalid data_url")
    mime = m.group("mime")
    ext = {"image/jpeg":"jpg","image/png":"png","image/webp":"webp","video/mp4":"mp4","video/webm":"webm"}.get(mime, "bin")
    raw = base64.b64decode(m.group("b64"))
    fname = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(UPLOAD_DIR, fname)
    with open(path, "wb") as f:
        f.write(raw)
    return f"/uploads/{fname}"

def current_user(db: Session):
    # demo: always ensure 'you' exists and act as that user
    me = db.query(User).filter_by(username="you").first()
    if not me:
        me = User(username="you", avatar="hsl(200,80%,60%)", bio="bio: shipping 🚀")
        db.add(me); db.commit(); db.refresh(me)
    return me

def score_post(p: Post, is_following: bool) -> float:
    # recency hours + log likes + follow boost
    age_h = (datetime.utcnow() - p.created_at).total_seconds() / 3600.0
    recency = max(0.0, 48.0 - age_h)
    import math
    like_boost = math.log10(1 + p.likes) * 4.0
    follow_boost = 8.0 if is_following else 0.0
    return recency + like_boost + follow_boost

@app.get("/uploads/<path:filename>")
def serve_upload(filename):
    return send_from_directory(UPLOAD_DIR, filename)

# ---- API ----

@app.get("/api/me")
def get_me():
    db = SessionLocal()
    me = current_user(db)
    following = [f.followee_id for f in db.query(Follow).filter(Follow.follower_id==me.id)]
    return jsonify({"id": me.id, "username": me.username, "avatar": me.avatar, "bio": me.bio, "following": following})

@app.post("/api/posts")
def create_post():
    db = SessionLocal()
    me = current_user(db)
    data = request.get_json()
    try:
        media = data.get("media", {})
        media_url = save_data_url(media.get("data_url"))
        media_type = media.get("type", "image")
        kind = data.get("kind", "post")
        caption = data.get("caption", "")
        tags = ",".join(data.get("tags", []))
        allow_comments = bool(data.get("allow_comments", True))
        post = Post(kind=kind, user_id=me.id, media_type=media_type, media_url=media_url,
                    caption=caption, tags=tags, allow_comments=allow_comments, likes=0)
        db.add(post); db.commit(); db.refresh(post)
        return jsonify({"id": post.id, "media_url": post.media_url}), 201
    except Exception as e:
        db.rollback()
        return jsonify({"error": str(e)}), 400
    finally:
        db.close()

@app.get("/api/posts")
def list_posts():
    db = SessionLocal()
    me = current_user(db)
    mode = request.args.get("mode", "ranked")
    q = request.args.get("q", "").lower().strip()
    posts = db.query(Post).order_by(Post.created_at.desc()).all()

    # filter by following
    if mode == "following":
        following_ids = [f.followee_id for f in db.query(Follow).filter(Follow.follower_id==me.id)]
        posts = [p for p in posts if p.user_id in following_ids or p.user_id == me.id]

    # search
    if q:
        def include(p):
            cap = (p.caption or "").lower()
            tags = (p.tags or "").lower()
            user = db.get(User, p.user_id).username.lower()
            return (q in cap) or (q in tags) or (q in user)
        posts = [p for p in posts if include(p)]

    # ranking
    if mode == "ranked" and not q:
        following_ids = {f.followee_id for f in db.query(Follow).filter(Follow.follower_id==me.id)}
        posts.sort(key=lambda p: score_post(p, p.user_id in following_ids), reverse=True)

    # serialize
    out = []
    for p in posts:
        user = db.get(User, p.user_id)
        out.append({
            "id": p.id, "kind": p.kind, "user": user.username, "avatar": user.avatar,
            "media": {"type": p.media_type, "src": p.media_url},
            "caption": p.caption, "tags": [t for t in (p.tags or "").split(",") if t],
            "likes": p.likes, "allowComments": p.allow_comments,
            "comments": [{"id": c.id, "user": db.get(User, c.user_id).username, "text": c.text, "ts": c.created_at.timestamp()} for c in p.comments],
            "ts": p.created_at.timestamp()
        })
    db.close()
    return jsonify(out)

@app.patch("/api/posts/<int:post_id>/like")
def like_post(post_id):
    db = SessionLocal()
    me = current_user(db)
    post = db.get(Post, post_id)
    if not post:
        db.close()
        return jsonify({"error": "not found"}), 404
    inc = int(request.args.get("inc", 1))
    post.likes = max(0, post.likes + inc)
    db.add(Notification(user_id=post.user_id, actor=me.username, action=("liked your post" if inc>0 else "unliked your post")))
    db.commit()
    db.close()
    return jsonify({"ok": True, "likes": post.likes})

@app.post("/api/comments")
def add_comment():
    db = SessionLocal()
    me = current_user(db)
    data = request.get_json()
    post_id = int(data.get("post_id"))
    text = data.get("text", "").strip()
    if not text:
        db.close()
        return jsonify({"error": "empty comment"}), 400
    c = Comment(post_id=post_id, user_id=me.id, text=text)
    post = db.get(Post, post_id)
    db.add(c)
    db.add(Notification(user_id=post.user_id, actor=me.username, action="commented on your post"))
    db.commit()
    db.close()
    return jsonify({"ok": True})

@app.post("/api/follow")
def follow_user():
    db = SessionLocal()
    me = current_user(db)
    username = request.get_json().get("username")
    u = db.query(User).filter_by(username=username).first()
    if not u:
        db.close()
        return jsonify({"error": "user not found"}), 404
    exists = db.query(Follow).filter_by(follower_id=me.id, followee_id=u.id).first()
    if not exists:
        db.add(Follow(follower_id=me.id, followee_id=u.id))
        db.add(Notification(user_id=u.id, actor=me.username, action="started following you"))
        db.commit()
    db.close()
    return jsonify({"ok": True})

@app.delete("/api/follow/<username>")
def unfollow_user(username):
    db = SessionLocal()
    me = current_user(db)
    u = db.query(User).filter_by(username=username).first()
    if not u:
        db.close()
        return jsonify({"error": "user not found"}), 404
    db.query(Follow).filter_by(follower_id=me.id, followee_id=u.id).delete()
    db.commit(); db.close()
    return jsonify({"ok": True})

@app.get("/api/notifications")
def list_notifications():
    db = SessionLocal()
    me = current_user(db)
    items = db.query(Notification).filter(Notification.user_id==me.id).order_by(Notification.created_at.desc()).limit(50).all()
    out = [{"id": n.id, "from": n.actor, "action": n.action, "ts": n.created_at.timestamp()} for n in items]
    db.close()
    return jsonify(out)

@app.post("/api/stories")
def new_story():
    db = SessionLocal()
    me = current_user(db)
    data = request.get_json()
    media_url = save_data_url(data.get("data_url"))
    s = Story(user_id=me.id, media_url=media_url)
    db.add(s); db.commit()
    db.close()
    return jsonify({"ok": True})

@app.get("/api/stories")
def list_stories():
    db = SessionLocal()
    items = db.query(Story).order_by(Story.created_at.desc()).limit(50).all()
    out = []
    for s in items:
        u = db.get(User, s.user_id)
        out.append({"id": s.id, "user": u.username, "avatar": u.avatar, "src": s.media_url, "ts": s.created_at.timestamp()})
    db.close()
    return jsonify(out)

@app.post("/api/collections")
def new_collection():
    db = SessionLocal()
    me = current_user(db)
    name = request.get_json().get("name", "Untitled")
    c = Collection(user_id=me.id, name=name)
    db.add(c); db.commit(); db.refresh(c); db.close()
    return jsonify({"id": c.id, "name": c.name})

@app.post("/api/collections/<int:cid>/save")
def save_to_collection(cid):
    db = SessionLocal()
    me = current_user(db)
    post_id = int(request.get_json().get("post_id"))
    # ensure collection belongs to me
    c = db.get(Collection, cid)
    if not c or c.user_id != me.id:
        db.close()
        return jsonify({"error": "collection not found"}), 404
    exists = db.query(CollectionItem).filter_by(collection_id=cid, post_id=post_id).first()
    if not exists:
        db.add(CollectionItem(collection_id=cid, post_id=post_id))
        db.add(Notification(user_id=me.id, actor="you", action=f"saved post #{post_id} to {c.name}"))
        db.commit()
    db.close()
    return jsonify({"ok": True})

@app.post("/api/seed")
def seed_demo():
    \"\"\"Quickly seed users + posts with placeholder images (data URLs expected).\"\"\"
    db = SessionLocal()
    me = current_user(db)
    usernames = ["neo","trinity","morpheus","switch","oracle","tank","dozer","mouse"]
    for name in usernames:
        if not db.query(User).filter_by(username=name).first():
            db.add(User(username=name, avatar=f"hsl({hash(name)%360},80%,60%)", bio=f"{name} bio"))
    db.commit()
    # Add a couple of posts if empty
    if db.query(Post).count() < 4:
        import datetime
        for i, name in enumerate(usernames[:6]):
            u = db.query(User).filter_by(username=name).first()
            p = Post(kind="post", user_id=u.id, media_type="image", media_url="/uploads/placeholder.png",
                     caption=f"vibes day {i+1} #prototype #{name}", tags=f"#prototype,#vibes,#{name}", likes=10+i*7,
                     allow_comments=True, created_at=datetime.datetime.utcnow())
            db.add(p)
        db.commit()
    db.close()
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
