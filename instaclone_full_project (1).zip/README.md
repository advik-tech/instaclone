# Instaclone Backend (Flask + SQLite)

Minimal API to give the single-file front-end a real database.

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

This starts a server at http://localhost:5000 . Media files are saved to `uploads/` and served at `/uploads/<filename>`.

## Endpoints (v1)

- `GET /api/me` → current user (`you`) metadata
- `GET /api/posts?mode=ranked|latest|following&q=query` → list posts
- `POST /api/posts` (JSON) → create post from a Data URL

Example body:
```json
{
  "kind":"post",
  "caption":"hello #prototype",
  "tags":["#prototype"],
  "allow_comments": true,
  "media": {"type":"image","data_url":"data:image/png;base64,AAAA..."}
}
```

- `PATCH /api/posts/<id>/like?inc=1|-1` → like/unlike
- `POST /api/comments` { "post_id": 1, "text": "nice!" }
- `POST /api/follow` { "username": "neo" }
- `DELETE /api/follow/<username>`
- `GET /api/stories` / `POST /api/stories` { "data_url": "data:image/png;base64,..." }
- `GET /api/notifications`
- `POST /api/collections` { "name": "Favorites" }
- `POST /api/collections/<id>/save` { "post_id": 123 }

## Seeding

`POST /api/seed` will create common Matrix users and a few sample posts (using a placeholder asset).

## Front-end integration

Replace local `state` mutations with `fetch()` calls to these endpoints. For example, to create a post from the Insane prototype:

```js
async function createPostViaAPI(dataURL, caption, tags=[], asReel=false, allowComments=true){
  const res = await fetch("http://localhost:5000/api/posts", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      kind: asReel ? "reel" : "post",
      caption, tags, allow_comments: allowComments,
      media: {type: dataURL.startsWith("data:video") ? "video" : "image", data_url: dataURL}
    })
  });
  return await res.json();
}
```

Then swap read-paths like `renderFeed()` to call `GET /api/posts?...` instead of reading localStorage.
