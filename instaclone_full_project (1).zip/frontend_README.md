# Front-end (index.html)

This `index.html` is the single-file front-end demo (Insane prototype). It's cozy to run straight from the filesystem (open in browser).
If you want it to use the backend API you started earlier, replace the localStorage state operations with fetch calls to `http://localhost:5000/api/...` as described in the backend README.
